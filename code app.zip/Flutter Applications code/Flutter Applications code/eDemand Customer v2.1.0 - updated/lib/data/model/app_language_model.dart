class AppLanguage {

  const AppLanguage({required this.languageCode, required this.languageName,required this.imageURL});
  final String languageName;
  final String languageCode;
  final String imageURL;
}
