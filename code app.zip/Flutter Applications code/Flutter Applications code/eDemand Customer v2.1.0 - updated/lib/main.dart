import 'package:e_demand/app/app.dart';

void main() => initApp();
