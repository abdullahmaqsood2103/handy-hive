import 'package:edemand_partner/ui/widgets/htmlEditor.dart';
import 'package:edemand_partner/utils/appQuickActions.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:geolocator_platform_interface/src/models/position.dart';
import 'package:html_editor_enhanced/html_editor.dart';
import 'package:intl/intl.dart';

import '../../../app/generalImports.dart';
import '../../../utils/location.dart';
import '../../widgets/bottomSheets/showImagePickerOptionBottomSheet.dart';
import 'map.dart';

class RegistrationForm extends StatefulWidget {
  const RegistrationForm({super.key, required this.isEditing});
  final bool isEditing;

  @override
  RegistrationFormState createState() => RegistrationFormState();

  static Route<RegistrationForm> route(RouteSettings routeSettings) {
    final Map<String, dynamic> parameters =
        routeSettings.arguments as Map<String, dynamic>;

    return CupertinoPageRoute(
      builder: (_) => BlocProvider(
        create: (BuildContext context) => EditProviderDetailsCubit(),
        child: RegistrationForm(
          isEditing: parameters['isEditing'],
        ),
      ),
    );
  }
}

class RegistrationFormState extends State<RegistrationForm>
    with ChangeNotifier {
  int totalForms = 6;

  int currentIndex = 1;

  final GlobalKey<FormState> formKey1 = GlobalKey<FormState>();
  final GlobalKey<FormState> formKey2 = GlobalKey<FormState>();
  final GlobalKey<FormState> formKey4 = GlobalKey<FormState>();
  final GlobalKey<FormState> formKey5 = GlobalKey<FormState>();
  final GlobalKey<FormState> formKey6 = GlobalKey<FormState>();

  ScrollController scrollController = ScrollController();
  HtmlEditorController htmlController = HtmlEditorController();

  ///form1
  TextEditingController userNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController mobileNumberController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  FocusNode userNmFocus = FocusNode();
  FocusNode emailFocus = FocusNode();
  FocusNode mobNoFocus = FocusNode();
  FocusNode passwordFocus = FocusNode();
  FocusNode confirmPasswordFocus = FocusNode();

  Map<String, dynamic> pickedLocalImages = {
    'nationalIdImage': '',
    'addressIdImage': '',
    'passportIdImage': '',
    'logoImage': '',
    'bannerImage': ''
  };

  ///form2
  TextEditingController cityController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController latitudeController = TextEditingController();
  TextEditingController longitudeController = TextEditingController();
  TextEditingController companyNameController = TextEditingController();
  TextEditingController aboutCompanyController = TextEditingController();
  TextEditingController visitingChargesController = TextEditingController();
  TextEditingController advanceBookingDaysController = TextEditingController();
  TextEditingController numberOfMemberController = TextEditingController();

  FocusNode aboutCompanyFocus = FocusNode();
  FocusNode cityFocus = FocusNode();
  FocusNode addressFocus = FocusNode();
  FocusNode latitudeFocus = FocusNode();
  FocusNode longitudeFocus = FocusNode();
  FocusNode companyNmFocus = FocusNode();
  FocusNode visitingChargeFocus = FocusNode();
  FocusNode advanceBookingDaysFocus = FocusNode();
  FocusNode numberOfMemberFocus = FocusNode();
  Map? selectCompanyType;
  Map companyType = {'0': 'Individual', '1': 'Organisation'};

  ///form3
  List<bool> isChecked =
      List<bool>.generate(7, (int index) => false); //7 = daysOfWeek.length
  List<TimeOfDay> selectedStartTime = [];
  List<TimeOfDay> selectedEndTime = [];

  late List<String> daysOfWeek = [
    'sunLbl'.translate(context: context),
    'monLbl'.translate(context: context),
    'tueLbl'.translate(context: context),
    'wedLbl'.translate(context: context),
    'thuLbl'.translate(context: context),
    'friLbl'.translate(context: context),
    'satLbl'.translate(context: context),
  ];

  late List<String> daysInWeek = [
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
    'sunday'
  ];

  ///form4
  TextEditingController bankNameController = TextEditingController();
  TextEditingController bankCodeController = TextEditingController();
  TextEditingController accountNameController = TextEditingController();
  TextEditingController accountNumberController = TextEditingController();
  TextEditingController taxNameController = TextEditingController();
  TextEditingController taxNumberController = TextEditingController();
  TextEditingController swiftCodeController = TextEditingController();

  FocusNode bankNameFocus = FocusNode();
  FocusNode bankCodeFocus = FocusNode();
  FocusNode bankAccountNumberFocus = FocusNode();
  FocusNode accountNameFocus = FocusNode();
  FocusNode accountNumberFocus = FocusNode();
  FocusNode taxNameFocus = FocusNode();
  FocusNode taxNumberFocus = FocusNode();
  FocusNode swiftCodeFocus = FocusNode();

  PickImage pickLogoImage = PickImage();
  PickImage pickBannerImage = PickImage();
  PickImage pickAddressProofImage = PickImage();
  PickImage pickPassportImage = PickImage();
  PickImage pickNationalIdImage = PickImage();

  ProviderDetails? providerData;
  bool? isIndividualType;

  String? longDescription;
  ValueNotifier<List<String>> pickedOtherImages = ValueNotifier([]);
  List<String>? previouslyAddedOtherImages = [];

  @override
  void initState() {
    super.initState();

    initializeData();
  }

  void initializeData() {
    Future.delayed(Duration.zero).then((value) {
      //
      providerData = context.read<ProviderDetailsCubit>().providerDetails;
      //
      userNameController.text = providerData?.user?.username ?? '';
      emailController.text = providerData?.user?.email ?? '';
      mobileNumberController.text =
          "${providerData?.user?.countryCode ?? ""} ${providerData?.user?.phone ?? ""}";
      companyNameController.text =
          providerData?.providerInformation?.companyName ?? '';
      aboutCompanyController.text =
          providerData?.providerInformation?.about ?? '';
      //
      bankNameController.text = providerData?.bankInformation?.bankName ?? '';
      bankCodeController.text = providerData?.bankInformation?.bankCode ?? '';
      accountNameController.text =
          providerData?.bankInformation?.accountName ?? '';
      accountNumberController.text =
          providerData?.bankInformation?.accountNumber ?? '';
      taxNameController.text = providerData?.bankInformation?.taxName ?? '';
      taxNumberController.text = providerData?.bankInformation?.taxNumber ?? '';
      swiftCodeController.text = providerData?.bankInformation?.swiftCode ?? '';
      //
      cityController.text = providerData?.locationInformation?.city ?? '';
      addressController.text = providerData?.locationInformation?.address ?? '';
      latitudeController.text =
          providerData?.locationInformation?.latitude ?? '';
      longitudeController.text =
          providerData?.locationInformation?.longitude ?? '';
      companyNameController.text =
          providerData?.providerInformation?.companyName ?? '';
      aboutCompanyController.text =
          providerData?.providerInformation?.about ?? '';
      visitingChargesController.text =
          providerData?.providerInformation?.visitingCharges ?? '';
      advanceBookingDaysController.text =
          providerData?.providerInformation?.advanceBookingDays ?? '';
      numberOfMemberController.text =
          providerData?.providerInformation?.numberOfMembers ?? '';
      selectCompanyType = providerData?.providerInformation?.type == '1'
          ? {'title': 'Individual', 'value': '0'}
          : {'title': 'Organization', 'value': '1'};
      isIndividualType = providerData?.providerInformation?.type == '1';
      //add elements in TimeOfDay List
      for (int i = 0; i < daysInWeek.length; i++) {
        //assign Default time @ start
        final List<String> startTime =
            (providerData?.workingDays?[i].startTime ?? '09:00:00').split(':');
        final List<String> endTime =
            (providerData?.workingDays?[i].endTime ?? '18:00:00').split(':');

        final int startTimeHour = int.parse(startTime[0]);
        final int startTimeMinute = int.parse(startTime[1]);
        selectedStartTime.insert(
            i, TimeOfDay(hour: startTimeHour, minute: startTimeMinute),);
        //
        final int endTimeHour = int.parse(endTime[0]);
        final int endTimeMinute = int.parse(endTime[1]);
        selectedEndTime.insert(
            i, TimeOfDay(hour: endTimeHour, minute: endTimeMinute),);
        isChecked[i] = providerData?.workingDays?[i].isOpen == 1;
      }

      longDescription = providerData?.providerInformation?.longDescription;
      previouslyAddedOtherImages =
          providerData?.providerInformation?.otherImages;
    });
    setState(() {});
  }

  @override
  void dispose() {
    userNameController.dispose();
    emailController.dispose();
    mobileNumberController.dispose();
    companyNameController.dispose();
    visitingChargesController.dispose();
    advanceBookingDaysController.dispose();
    numberOfMemberController.dispose();
    aboutCompanyController.dispose();
    cityController.dispose();
    latitudeController.dispose();
    longitudeController.dispose();
    addressController.dispose();
    bankNameController.dispose();
    bankCodeController.dispose();
    accountNameController.dispose();
    accountNumberController.dispose();
    taxNumberController.dispose();
    taxNameController.dispose();
    swiftCodeController.dispose();
    pickedLocalImages.clear();
    pickedOtherImages.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: UiUtils.getSystemUiOverlayStyle(context: context),
      child: SafeArea(
        child: WillPopScope(
          onWillPop: () async {
            if (currentIndex > 1) {
              currentIndex--;
              pickedLocalImages = pickedLocalImages;
              setState(() {});
              return false;
            }
            return true;
          },
          child: Scaffold(
            backgroundColor: Theme.of(context).colorScheme.primaryColor,
            appBar: AppBar(
              elevation: 1,
              centerTitle: true,
              title: CustomText(
                titleText: widget.isEditing
                    ? 'editDetails'.translate(context: context)
                    : 'completeKYCDetails'.translate(context: context),
                fontColor: Theme.of(context).colorScheme.blackColor,
                fontWeight: FontWeight.bold,
              ),
              leading: widget.isEditing
                  ? UiUtils.setBackArrow(
                      context,
                      onTap: () {
                        if (currentIndex > 1) {
                          currentIndex--;
                          pickedLocalImages = pickedLocalImages;
                          setState(() {});
                          return;
                        }
                        Navigator.pop(context);
                      },
                    )
                  : null,
              backgroundColor: Theme.of(context).colorScheme.secondaryColor,
              actions: <Widget>[
                PageNumberIndicator(
                    currentIndex: currentIndex, total: totalForms,)
              ],
            ),
            bottomNavigationBar: bottomNavigation(currentIndex: currentIndex),
            body: screenBuilder(currentIndex),
          ),
        ),
      ),
    );
  }

  Padding bottomNavigation({required int currentIndex}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (currentIndex > 1) ...[
            Expanded(
                child: nextPrevBtnWidget(
                    isNext: false, currentIndex: currentIndex,),),
            const SizedBox(width: 10),
          ],
          Expanded(
              child:
                  nextPrevBtnWidget(isNext: true, currentIndex: currentIndex),),
        ],
      ),
    );
  }

  BlocConsumer<EditProviderDetailsCubit, EditProviderDetailsState>
      nextPrevBtnWidget({required bool isNext, required int currentIndex}) {
    return BlocConsumer<EditProviderDetailsCubit, EditProviderDetailsState>(
      listener: (BuildContext context, EditProviderDetailsState state) async {
        if (state is EditProviderDetailsSuccess) {
          UiUtils.showMessage(
            context,
            'detailsUpdatedSuccessfully'.translate(context: context),
            MessageType.success,
          );
          //

          //
          if (widget.isEditing) {
            context.read<ProviderDetailsCubit>().setUserInfo(state.providerDetails);
            Future.delayed(const Duration(seconds: 1)).then((value) {
              Navigator.pop(context);
            });
          } else {
            await HiveUtils.logoutUser(
              onLogout: () {
                //
                NotificationService.disposeListeners();
                AppQuickActions.clearShortcutItems();
                context.read<AuthenticationCubit>().setUnAuthenticated();
                //
              },
            );
//
            Future.delayed(const Duration(seconds: 1)).then((value) {
              Navigator.pushReplacementNamed(
                context,
                Routes.successScreen,
                arguments: {
                  'title': 'detailsSubmitted'.translate(context: context),
                  'message': 'detailsHasBeenSubmittedWaitForAdminApproval'
                      .translate(context: context),
                  'imageName': 'registration'
                },
              );
            });
          }
        } else if (state is EditProviderDetailsFailure) {
          UiUtils.showMessage(
            context,
            state.errorMessage.translate(context: context),
            MessageType.error,
          );
        }
      },
      builder: (BuildContext context, EditProviderDetailsState state) {
        Widget? child;
        if (state is EditProviderDetailsInProgress) {
          child = CircularProgressIndicator(
            color: AppColors.whiteColors,
          );
        } else if (state is EditProviderDetailsSuccess ||
            state is EditProviderDetailsFailure) {
          child = null;
        }
        return CustomRoundedButton(
          widthPercentage: isNext ? 1 : 0.5,
          backgroundColor: isNext
              ? Theme.of(context).colorScheme.accentColor
              : Theme.of(context).colorScheme.primaryColor,
          buttonTitle: isNext && currentIndex >= totalForms
              ? 'submitBtnLbl'.translate(context: context)
              : isNext
                  ? 'nxtBtnLbl'.translate(context: context)
                  : 'prevBtnLbl'.translate(context: context),
          showBorder: isNext ? false : true,
          borderColor: Theme.of(context).colorScheme.blackColor,
          titleColor: isNext
              ? AppColors.whiteColors
              : Theme.of(context).colorScheme.blackColor,
          onTap: () => state is EditProviderDetailsInProgress
              ? () {}
              : onNextPrevBtnClick(isNext: isNext, currentPage: currentIndex),
          child: isNext && currentIndex >= totalForms ? child : null,
        );
      },
    );
  }

  Future<void> onNextPrevBtnClick(
      {required bool isNext, required int currentPage,}) async {
    if (currentPage == 3) {
      final tempText = await htmlController.getText();

      if (tempText.trim().isNotEmpty) {
        longDescription = tempText;
      }
    }
    if (isNext) {
      FormState? form = formKey1.currentState; //default value
      switch (currentPage) {
        case 2:
          form = formKey2.currentState;
          break;
        case 4:
          form = formKey4.currentState;
          break;
        case 5:
          form = formKey5.currentState;
          break;
        case 6:
          form = formKey6.currentState;
          break;
        default:
          form = formKey1.currentState;
          break;
      }
      if (currentPage != 3) {
        if (form == null) return;
        form.save();
      }

      if (currentPage == 3 || form!.validate()) {
        if (currentPage < totalForms) {
          currentIndex++;
          if (currentPage != 3) {
            scrollController.jumpTo(0); //reset Scrolling on Form change
          }
          pickedLocalImages = pickedLocalImages;
          setState(() {});
        } else {
          final List<WorkingDay> workingDays = [];
          for (int i = 0; i < daysInWeek.length; i++) {
            //
            workingDays.add(
              WorkingDay(
                isOpen: isChecked[i] ? 1 : 0,
                endTime:
                    "${selectedEndTime[i].hour.toString().padLeft(2, "0")}:${selectedEndTime[i].minute.toString().padLeft(2, "0")}:00",
                startTime:
                    "${selectedStartTime[i].hour.toString().padLeft(2, "0")}:${selectedStartTime[i].minute.toString().padLeft(2, "0")}:00",
                day: daysInWeek[i],
              ),
            );
          }

          final ProviderDetails editProviderDetails = ProviderDetails(
            user: UserDetails(
              id: providerData?.user?.id,
              username: userNameController.text.trim(),
              email: emailController.text.trim(),
              phone: providerData?.user?.phone,
              countryCode: providerData?.user?.countryCode,
              company: companyNameController.text.trim(),
              image: pickedLocalImages['logoImage'],
            ),
            providerInformation: ProviderInformation(
              type: selectCompanyType?['value'],
              companyName: companyNameController.text.trim(),
              visitingCharges: visitingChargesController.text.trim(),
              advanceBookingDays: advanceBookingDaysController.text.trim(),
              about: aboutCompanyController.text.trim(),
              numberOfMembers: numberOfMemberController.text.trim(),
              banner: pickedLocalImages['bannerImage'],
              nationalId: pickedLocalImages['nationalIdImage'],
              passport: pickedLocalImages['passportIdImage'],
              addressId: pickedLocalImages['addressIdImage'],
              otherImages: pickedOtherImages.value,
              longDescription: longDescription,
            ),
            bankInformation: BankInformation(
              accountName: accountNameController.text.trim(),
              accountNumber: accountNumberController.text.trim(),
              bankCode: bankCodeController.text.trim(),
              bankName: bankNameController.text.trim(),
              taxName: taxNameController.text.trim(),
              taxNumber: taxNumberController.text.trim(),
              swiftCode: swiftCodeController.text.trim(),
            ),
            locationInformation: LocationInformation(
              longitude: longitudeController.text.trim(),
              latitude: latitudeController.text.trim(),
              address: addressController.text.trim(),
              city: cityController.text.trim(),
            ),
            workingDays: workingDays,
          );
          //
          if (context.read<FetchSystemSettingsCubit>().isDemoModeEnable() &&
              widget.isEditing) {
            UiUtils.showDemoModeWarning(context: context);
            return;
          }
          context
              .read<EditProviderDetailsCubit>()
              .editProviderDetails(providerDetails: editProviderDetails);
        }
      }
    } else if (currentPage > 1) {
      currentIndex--;
      pickedLocalImages = pickedLocalImages;
      setState(() {});
    }
  }

  Widget screenBuilder(int currentPage) {
    Widget currentForm = form1(); //default form1
    switch (currentPage) {
      case 2:
        currentForm = form2();
        break;
      case 3:
        currentForm = form3();
        break;
      case 4:
        currentForm = form4();
        break;
      case 5:
        currentForm = form5();
        break;
      case 6:
        currentForm = form6();
        break;
      default:
        currentForm = form1();
        break;
    }
    return currentPage == 3
        ? currentForm
        : SingleChildScrollView(
            clipBehavior: Clip.none,
            padding: const EdgeInsets.all(15),
            controller: scrollController,
            physics: const AlwaysScrollableScrollPhysics(),
            child: currentForm,
          );
  }

  Widget form1() {
    return Form(
      key: formKey1,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            titleText: 'personalDetails'.translate(context: context),
            fontColor: Theme.of(context).colorScheme.blackColor,
          ),
          UiUtils.setDivider(context: context),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'userNmLbl'.translate(context: context),
            controller: userNameController,
            currNode: userNmFocus,
            nextFocus: emailFocus,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'emailLbl'.translate(context: context),
            controller: emailController,
            currNode: emailFocus,
            nextFocus: mobNoFocus,
            textInputType: TextInputType.emailAddress,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'mobNoLbl'.translate(context: context),
            controller: mobileNumberController,
            currNode: mobNoFocus,
            textInputType: TextInputType.phone,
            isReadOnly: true,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
          ),
          /*UiUtils.setTitleAndTFF(context, titleText: UiUtils.getTranslatedLabel(context, "passwordLbl"), controller: passwordController, currNode: passwordFocus, nextFocus: confirmPasswordFocus, isPswd: true),
            UiUtils.setTitleAndTFF(context,
                titleText: UiUtils.getTranslatedLabel(context, "confirmPasswordLbl"), controller: confirmPasswordController, currNode: confirmPasswordFocus, nextFocus: companyNmFocus, isPswd: true),*/

          const SizedBox(
            height: 12,
          ),
          CustomText(
            titleText: 'idProofLbl'.translate(context: context),
            fontColor: Theme.of(context).colorScheme.blackColor,
          ),
          UiUtils.setDivider(context: context),
          Padding(
            padding: const EdgeInsets.all(3.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                idImageWidget(
                  imageController: pickNationalIdImage,
                  titleTxt: 'nationalIdLbl'.translate(context: context),
                  imageHintText: 'chooseFileLbl'.translate(context: context),
                  imageType: 'nationalIdImage',
                  oldImage: context
                          .read<ProviderDetailsCubit>()
                          .providerDetails
                          .providerInformation
                          ?.nationalId ??
                      '',
                ),
                idImageWidget(
                  imageController: pickAddressProofImage,
                  titleTxt: 'addressLabel'.translate(context: context),
                  imageHintText: 'chooseFileLbl'.translate(context: context),
                  imageType: 'addressIdImage',
                  oldImage: context
                          .read<ProviderDetailsCubit>()
                          .providerDetails
                          .providerInformation
                          ?.addressId ??
                      '',
                ),
                idImageWidget(
                  imageController: pickPassportImage,
                  titleTxt: 'passportLbl'.translate(context: context),
                  imageHintText: 'chooseFileLbl'.translate(context: context),
                  imageType: 'passportIdImage',
                  oldImage: context
                          .read<ProviderDetailsCubit>()
                          .providerDetails
                          .providerInformation
                          ?.passport ??
                      '',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget form2() {
    return Form(
      key: formKey2,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            titleText: 'companyDetails'.translate(context: context),
            fontColor: Theme.of(context).colorScheme.blackColor,
          ),
          UiUtils.setDivider(context: context),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'compNmLbl'.translate(context: context),
            controller: companyNameController,
            currNode: companyNmFocus,
            nextFocus: visitingChargeFocus,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'visitingCharge'.translate(context: context),
            controller: visitingChargesController,
            currNode: visitingChargeFocus,
            nextFocus: companyNmFocus,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
            textInputType: TextInputType.number,
            allowOnlySingleDecimalPoint: true,
            prefix: Padding(
              padding: const EdgeInsetsDirectional.only(start: 15, end: 15),
              child: IntrinsicHeight(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomText(
                      titleText: Constant.systemCurrency ?? '',
                      fontSize: 15.0,
                      fontColor: Theme.of(context).colorScheme.blackColor,
                    ),
                    VerticalDivider(
                      color: Theme.of(context)
                          .colorScheme
                          .blackColor
                          .withAlpha(150),
                      thickness: 1,
                    ),
                  ],
                ),
              ),
            ),
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'advanceBookingDay'.translate(context: context),
            controller: advanceBookingDaysController,
            currNode: advanceBookingDaysFocus,
            nextFocus: numberOfMemberFocus,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
            textInputType: TextInputType.number,
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'aboutCompany'.translate(context: context),
            controller: aboutCompanyController,
            currNode: aboutCompanyFocus,
            minLines: 3,
            expands: true,
            textInputType: TextInputType.multiline,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
          ),
          buildDropDown(
            context,
            title: 'selectType'.translate(context: context),
            initialValue: selectCompanyType?['title'] ??
                'selectType'.translate(context: context),
            value: companyType[selectCompanyType]?['value'],
            onTap: () {
              selectCompanyTypes();
            },
          ),
          const SizedBox(
            height: 16,
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'numberOfMember'.translate(context: context),
            controller: numberOfMemberController,
            currNode: numberOfMemberFocus,
            nextFocus: aboutCompanyFocus,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
            isReadOnly: isIndividualType ?? false,
            textInputType: TextInputType.number,
          ),
          const SizedBox(
            height: 7,
          ),
          CustomText(
            titleText: 'logoLbl'.translate(context: context),
            fontColor: Theme.of(context).colorScheme.blackColor,
          ),
          const SizedBox(
            height: 7,
          ),
          imagePicker(
            imageController: pickLogoImage,
            oldImage: providerData?.user?.image ?? '',
            hintLabel:
                "${"addLbl".translate(context: context)} ${"logoLbl".translate(context: context)}",
            imageType: 'logoImage',
          ),
          const SizedBox(
            height: 12,
          ),
          CustomText(
            titleText: 'bannerImgLbl'.translate(context: context),
            fontColor: Theme.of(context).colorScheme.blackColor,
          ),
          const SizedBox(
            height: 7,
          ),
          imagePicker(
            imageController: pickBannerImage,
            oldImage: providerData?.providerInformation?.banner ?? '',
            hintLabel:
                "${"addLbl".translate(context: context)} ${"bannerImgLbl".translate(context: context)}",
            imageType: 'bannerImage',
          ),
          const SizedBox(height: 15),
          CustomText(
            titleText: 'otherImages'.translate(context: context),
            fontColor: Theme.of(context).colorScheme.blackColor,
          ),
          const SizedBox(height: 5),
          //other image picker builder
          ValueListenableBuilder(
            valueListenable: pickedOtherImages,
            builder: (BuildContext context, Object? value, Widget? child) {
              final bool isThereAnyImage = pickedOtherImages.value.isNotEmpty ||
                  (previouslyAddedOtherImages != null &&
                      previouslyAddedOtherImages!.isNotEmpty);
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: SizedBox(
                  height: isThereAnyImage ? 150 : 100,
                  width: double.maxFinite,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () async {
                            try {
                              final FilePickerResult? result =
                                  await FilePicker.platform.pickFiles(
                                allowMultiple: true,
                                type: FileType.image,
                              );
                              if (result != null) {
                                if (previouslyAddedOtherImages != null &&
                                    previouslyAddedOtherImages!.isNotEmpty) {
                                  previouslyAddedOtherImages = null;
                                }
                                for (int i = 0; i < result.files.length; i++) {
                                  if (!pickedOtherImages.value
                                      .contains(result.files[i].path)) {
                                    pickedOtherImages.value
                                        .insert(0, result.files[i].path!);
                                  }
                                }
                                pickedOtherImages.notifyListeners();
                              } else {
                                // User canceled the picker
                              }
                            } catch (_) {

                            }
                          },
                          child: Padding(
                            padding: EdgeInsets.only(
                              right: isThereAnyImage ? 5 : 0,
                            ),
                            child: SetDottedBorderWithHint(
                              height: double.maxFinite,
                              width: isThereAnyImage
                                  ? 100
                                  : MediaQuery.sizeOf(context).width - 35,
                              radius: 7,
                              str: (isThereAnyImage
                                      ? previouslyAddedOtherImages != null &&
                                              previouslyAddedOtherImages!
                                                  .isNotEmpty
                                          ? "changeImages"
                                          : "addImages"
                                      : "chooseImages")
                                  .translate(context: context),
                              strPrefix: '',
                              borderColor:
                                  Theme.of(context).colorScheme.blackColor,
                            ),
                          ),
                        ),
                        if (isThereAnyImage &&
                            pickedOtherImages.value.isNotEmpty)
                          for (int i = 0;
                              i < pickedOtherImages.value.length;
                              i++)
                            Container(
                              margin: const EdgeInsets.symmetric(horizontal: 5),
                              height: double.maxFinite,
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .blackColor
                                      .withOpacity(0.5),
                                ),
                              ),
                              child: Stack(
                                children: [
                                  Center(
                                    child: Image.file(
                                      File(
                                        pickedOtherImages.value[i],
                                      ),
                                      fit: BoxFit.fitHeight,
                                    ),
                                  ),
                                  Align(
                                    alignment: AlignmentDirectional.topEnd,
                                    child: InkWell(
                                      onTap: () {
                                        pickedOtherImages.value.removeAt(i);
                                        pickedOtherImages.notifyListeners();
                                      },
                                      child: Container(
                                        height: 20,
                                        width: 20,
                                        color: Colors.white54,
                                        child: const Center(
                                          child: Icon(
                                            Icons.clear_rounded,
                                            size: 15,
                                          ),
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                        if (isThereAnyImage &&
                            previouslyAddedOtherImages != null &&
                            previouslyAddedOtherImages!.isNotEmpty)
                          for (int i = 0;
                              i < previouslyAddedOtherImages!.length;
                              i++)
                            Container(
                              margin: const EdgeInsets.symmetric(horizontal: 5),
                              height: double.maxFinite,
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .blackColor
                                      .withOpacity(0.5),
                                ),
                              ),
                              child: Center(
                                child: CustomCachedNetworkImage(
                                  imageUrl: previouslyAddedOtherImages![i],
                                  fit: BoxFit.fitHeight,
                                ),
                              ),
                            ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(
            height: 12,
          ),
        ],
      ),
    );
  }

  Widget form3() {
    return SizedBox(
      height: double.maxFinite,
      child: CustomHTMLEditor(
        controller: htmlController,
        initialHTML: longDescription,
        hint: 'describeCompanyInDetail'.translate(context: context),
      ),
    );
  }

  Widget form6() {
    return Form(
      key: formKey6,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomText(
              titleText: 'locationInformation'.translate(context: context),
              fontColor: Theme.of(context).colorScheme.blackColor,
            ),
            UiUtils.setDivider(context: context),
            InkWell(
              onTap: () async {
                UiUtils.removeFocus();
                //
                String latitude = latitudeController.text.trim();
                String longitude = longitudeController.text.trim();
                if (latitude == '' && longitude == '') {
                  await GetLocation().requestPermission(
                    onGranted: (Position position) {
                      latitude = position.latitude.toString();
                      longitude = position.longitude.toString();
                    },
                    allowed: (Position position) {
                      latitude = position.latitude.toString();
                      longitude = position.longitude.toString();
                    },
                    onRejected: () {},
                  );
                }
                if (mounted) {
                  Navigator.push(
                    context,
                    CupertinoPageRoute(
                      builder: (BuildContext context) => GoogleMapScreen(
                        latitude: latitude,
                        longitude: longitude,
                      ),
                    ),
                  ).then((value) {
                    latitudeController.text = value['selectedLatitude'];
                    longitudeController.text = value['selectedLongitude'];
                    addressController.text = value['selectedAddress'];
                    cityController.text = value['selectedCity'];
                  });
                }
              },
              child: Container(
                margin: const EdgeInsets.only(bottom: 15, top: 5),
                height: 50,
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Theme.of(context).colorScheme.lightGreyColor,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Icon(Icons.my_location_sharp,
                        color: Theme.of(context).colorScheme.accentColor,),
                    Text(
                      'chooseYourLocation'.translate(context: context),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Theme.of(context).colorScheme.accentColor,),
                    ),
                    Icon(Icons.arrow_forward_ios,
                        color: Theme.of(context).colorScheme.accentColor,),
                  ],
                ),
              ),
            ),
            UiUtils.setTitleAndTFF(
              context,
              titleText: 'cityLbl'.translate(context: context),
              controller: cityController,
              currNode: cityFocus,
              nextFocus: latitudeFocus,
              validator: (String? cityValue) => Validator.nullCheck(cityValue),
            ),
            UiUtils.setTitleAndTFF(
              context,
              titleText: 'latitudeLbl'.translate(context: context),
              controller: latitudeController,
              currNode: latitudeFocus,
              nextFocus: longitudeFocus,
              textInputType: TextInputType.number,
              validator: (String? latitude) =>
                  Validator.validateLatitude(latitude),
              allowOnlySingleDecimalPoint: true,
            ),
            UiUtils.setTitleAndTFF(
              context,
              titleText: 'longitudeLbl'.translate(context: context),
              controller: longitudeController,
              currNode: longitudeFocus,
              nextFocus: addressFocus,
              textInputType: TextInputType.number,
              validator: (String? longitude) =>
                  Validator.validateLongitude(longitude),
              allowOnlySingleDecimalPoint: true,
            ),
            UiUtils.setTitleAndTFF(
              context,
              titleText: 'addressLbl'.translate(context: context),
              controller: addressController,
              currNode: addressFocus,
              textInputType: TextInputType.multiline,
              expands: true,
              minLines: 3,
              validator: (String? addressValue) =>
                  Validator.nullCheck(addressValue),
            ),
          ],
        ),
      ),
    );
  }

  Widget form4() {
    return Form(
      key: formKey4,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            titleText: 'workingDaysLbl'.translate(context: context),
            fontColor: Theme.of(context).colorScheme.blackColor,
          ),
          UiUtils.setDivider(context: context),
          ListView.builder(
            padding: EdgeInsets.zero,
            itemCount: daysOfWeek.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (BuildContext context, int index) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  setRow(titleTxt: daysOfWeek[index], indexVal: index),
                  if (isChecked[index])
                    setTimerPickerRow(index)
                  else
                    const SizedBox.shrink(),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget form5() {
    return Form(
      key: formKey5,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            titleText: 'bankDetailsLbl'.translate(context: context),
            fontColor: Theme.of(context).colorScheme.blackColor,
          ),
          UiUtils.setDivider(context: context),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'bankNmLbl'.translate(context: context),
            controller: bankNameController,
            currNode: bankNameFocus,
            nextFocus: bankCodeFocus,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'bankCodeLbl'.translate(context: context),
            controller: bankCodeController,
            currNode: bankCodeFocus,
            nextFocus: accountNameFocus,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'accountName'.translate(context: context),
            controller: accountNameController,
            currNode: accountNameFocus,
            nextFocus: accountNumberFocus,
            validator: (String? mobileNumber) =>
                Validator.nullCheck(mobileNumber),
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'accNumLbl'.translate(context: context),
            controller: accountNumberController,
            currNode: accountNumberFocus,
            nextFocus: taxNameFocus,
            textInputType: TextInputType.phone,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'taxName'.translate(context: context),
            controller: taxNameController,
            currNode: taxNameFocus,
            nextFocus: taxNumberFocus,
            validator: (String? mobileNumber) =>
                Validator.nullCheck(mobileNumber),
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'taxNumber'.translate(context: context),
            controller: taxNumberController,
            currNode: taxNumberFocus,
            nextFocus: swiftCodeFocus,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
            textInputType: const TextInputType.numberWithOptions(decimal: true),
          ),
          UiUtils.setTitleAndTFF(
            context,
            titleText: 'swiftCode'.translate(context: context),
            controller: swiftCodeController,
            currNode: swiftCodeFocus,
            validator: (String? cityValue) => Validator.nullCheck(cityValue),
          ),
        ],
      ),
    );
  }

  Widget setRow({required String titleTxt, required int indexVal}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Expanded(
            child: CustomText(
              titleText: titleTxt,
              fontColor: Theme.of(context).colorScheme.blackColor,
            ),
          ),
          // CustomText(titleText: "openLbl".translate(context: context)),
          const Spacer(),
          SizedBox(
            height: 24,
            width: 24,
            child: CheckBox(
              isChecked: isChecked,
              indexVal: indexVal,
              onChanged: (bool? checked) {
                setState(
                  () {
                    pickedLocalImages = pickedLocalImages;
                    isChecked[indexVal] = checked!;
                    // show/hide timePicker
                  },
                );
              },
            ),
          )
        ],
      ),
    );
  }

  Widget setTimerPickerRow(int indexVal) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        CustomRoundedButton(
          backgroundColor: Colors.transparent,
          widthPercentage: 0.3,
          // format time as AM/PM
          buttonTitle: DateFormat.jm().format(
            DateTime.parse(
              "2020-07-20T${selectedStartTime[indexVal].hour.toString().padLeft(2, "0")}:${selectedStartTime[indexVal].minute.toString().padLeft(2, "0")}:00",
            ),
          ),
          showBorder: true,
          borderColor: Theme.of(context).colorScheme.lightGreyColor,
          height: 43,
          textSize: 16,
          titleColor: Theme.of(context).colorScheme.blackColor,
          onTap: () {
            _selectTime(
              selectedTime: selectedStartTime[indexVal],
              indexVal: indexVal,
              isTimePickerForStarTime: true,
            );
          },
        ),
        CustomText(
          titleText: 'toLbl'.translate(context: context),
          fontColor: Theme.of(context).colorScheme.lightGreyColor,
          fontWeight: FontWeight.w400,
        ),
        CustomRoundedButton(
          backgroundColor: Colors.transparent,
          widthPercentage: 0.3,
          buttonTitle:
              "${DateFormat.jm().format(DateTime.parse("2020-07-20T${selectedEndTime[indexVal].hour.toString().padLeft(2, "0")}:${selectedEndTime[indexVal].minute.toString().padLeft(2, "0")}:00"))} ",
          showBorder: true,
          borderColor: Theme.of(context).colorScheme.lightGreyColor,
          height: 43,
          textSize: 16,
          titleColor: Theme.of(context).colorScheme.blackColor,
          onTap: () {
            _selectTime(
              selectedTime: selectedEndTime[indexVal],
              indexVal: indexVal,
              isTimePickerForStarTime: false,
            );
          },
        ),
      ],
    );
  }

  Future<void> _selectTime({
    required TimeOfDay selectedTime,
    required int indexVal,
    required bool isTimePickerForStarTime,
  }) async {
    try {
      final TimeOfDay? timeOfDay = await showTimePicker(
        context: context,
        initialTime: selectedTime, //TimeOfDay.now(),
        builder: (BuildContext context, Widget? child) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
            //To use 12 hours
            child: child!,
          );
        },
      );
      //

      if (isTimePickerForStarTime) {
        //
        final bool isStartTimeBeforeOfEndTime = timeOfDay!.hour <=
                (selectedEndTime[indexVal].hour == 00
                    ? 24
                    : selectedEndTime[indexVal].hour) &&
            timeOfDay.minute <= selectedEndTime[indexVal].minute;
        //
        if (isStartTimeBeforeOfEndTime) {
          selectedStartTime[indexVal] = timeOfDay;
        } else if (mounted) {
          UiUtils.showMessage(
            context,
            'companyStartTimeCanNotBeAfterOfEndTime'
                .translate(context: context),
            MessageType.warning,
          );
        }
      } else {
        //
        final bool isEndTimeAfterOfStartTime = timeOfDay!.hour >=
                (selectedStartTime[indexVal].hour == 00
                    ? 24
                    : selectedStartTime[indexVal].hour) &&
            timeOfDay.minute >= selectedStartTime[indexVal].minute;
        //
        if (isEndTimeAfterOfStartTime) {
          selectedEndTime[indexVal] = timeOfDay;
        } else {
          if (mounted) {
            UiUtils.showMessage(
              context,
              'companyEndTimeCanNotBeBeforeOfStartTime'
                  .translate(context: context),
              MessageType.warning,
            );
          }
        }
      }
    } catch (_) {}

    setState(() {
      pickedLocalImages = pickedLocalImages;
    });
  }

  Widget idImageWidget({
    required String titleTxt,
    required String imageHintText,
    required PickImage imageController,
    required String imageType,
    required String oldImage,
  }) {
    return Column(
      children: [
        CustomText(
          titleText: titleTxt,
        ),
        const SizedBox(height: 5),
        imagePicker(
          imageType: imageType,
          imageController: imageController,
          oldImage: oldImage,
          hintLabel: imageHintText,
          width: 100,
        ),
      ],
    );
  }

  Widget imagePicker({
    required PickImage imageController,
    required String oldImage,
    required String hintLabel,
    required String imageType,
    double? width,
  }) {
    return imageController.ListenImageChange(
      (BuildContext context, image) {
        if (image == null) {
          if (pickedLocalImages[imageType] != '') {
            return GestureDetector(
              onTap: () {
                showCameraAndGalleryOption(
                    imageController: imageController, title: hintLabel,);
              },
              child: Stack(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(3.0),
                    child: SizedBox(
                      height: 200,
                      width: width ?? MediaQuery.sizeOf(context).width,
                      child: Image.file(
                        File(pickedLocalImages[imageType]!),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 210,
                    width: (width ?? MediaQuery.sizeOf(context).width - 5) + 5,
                    child: DashedRect(
                      color: Theme.of(context).colorScheme.blackColor,
                      strokeWidth: 2.0,
                      gap: 4.0,
                    ),
                  ),
                ],
              ),
            );
          }
          if (oldImage.isNotEmpty) {
            return GestureDetector(
              onTap: () {
                showCameraAndGalleryOption(
                    imageController: imageController, title: hintLabel,);
              },
              child: Stack(
                children: [
                  SizedBox(
                    height: 210,
                    width: width ?? MediaQuery.sizeOf(context).width,
                    child: DashedRect(
                      color: Theme.of(context).colorScheme.blackColor,
                      strokeWidth: 2.0,
                      gap: 4.0,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(3.0),
                    child: SizedBox(
                      height: 200,
                      width: (width ?? MediaQuery.sizeOf(context).width) - 5.0,
                      child: CustomCachedNetworkImage(imageUrl: oldImage),
                    ),
                  ),
                ],
              ),
            );
          }

          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: InkWell(
              onTap: () {
                showCameraAndGalleryOption(
                    imageController: imageController, title: hintLabel,);
              },
              child: SetDottedBorderWithHint(
                height: 100,
                width: width ?? MediaQuery.sizeOf(context).width - 35,
                radius: 7,
                str: hintLabel,
                strPrefix: '',
                borderColor: Theme.of(context).colorScheme.blackColor,
              ),
            ),
          );
        }
        //
        pickedLocalImages[imageType] = image?.path;
        //
        return GestureDetector(
          onTap: () {
            showCameraAndGalleryOption(
                imageController: imageController, title: hintLabel,);
          },
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(3.0),
                child: SizedBox(
                  height: 200,
                  width: width ?? MediaQuery.sizeOf(context).width,
                  child: Image.file(
                    File(image.path),
                  ),
                ),
              ),
              SizedBox(
                height: 210,
                width: (width ?? MediaQuery.sizeOf(context).width - 5) + 5,
                child: DashedRect(
                  color: Theme.of(context).colorScheme.blackColor,
                  strokeWidth: 2.0,
                  gap: 4.0,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget buildDropDown(
    BuildContext context, {
    required String title,
    required VoidCallback onTap,
    required String initialValue,
    String? value,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomText(
          fontColor: Theme.of(context).colorScheme.blackColor,
          titleText: title,
          fontWeight: FontWeight.w400,
        ),
        SizedBox(
          height: 10.rh(context),
        ),
        CustomFormDropdown(
          onTap: () {
            onTap.call();
          },
          initialTitle: initialValue,
          selectedValue: value,
          validator: (String? p0) {
            return Validator.nullCheck(p0);
          },
        ),
      ],
    );
  }

  Future showCameraAndGalleryOption(
      {required PickImage imageController, required String title,}) {
    return UiUtils.showModelBottomSheets(
      backgroundColor: Theme.of(context).colorScheme.primaryColor,
      context: context,
      child: ShowImagePickerOptionBottomSheet(
        title: title,
        onCameraButtonClick: () {
          imageController.pick(source: ImageSource.camera);
        },
        onGalleryButtonClick: () {
          imageController.pick(source: ImageSource.gallery);
        },
      ),
    );
  }

  Future<void> selectCompanyTypes() async {
    final Map? result = await showDialog<Map>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return CustomDialogs.showSelectDialoge(
          selectedValue: selectCompanyType?['value'],
          itemList: <Map>[
            {'title': 'Individual'.translate(context: context), 'value': '0'},
            {'title': 'Organisation'.translate(context: context), 'value': '1'}
          ],
        );
      },
    );
    selectCompanyType = result;

    if (result?['title'] == 'Individual') {
      numberOfMemberController.text = '1';
      isIndividualType = true;
    } else {
      isIndividualType = false;
    }
    setState(() {
      pickedLocalImages = pickedLocalImages;
    });
  }
}
