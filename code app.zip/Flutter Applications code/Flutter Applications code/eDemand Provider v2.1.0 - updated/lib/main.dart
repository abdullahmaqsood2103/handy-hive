import 'app/app.dart';

void main() => initApp();
